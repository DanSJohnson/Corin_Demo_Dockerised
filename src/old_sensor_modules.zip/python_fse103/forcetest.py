
from fse103 import FSE103, list_serial_ports

sensor = FSE103("/dev/ttyACM0")

# print("Available Serial Ports:", list_serial_ports())

while True:
    sensor.read()
    print(sensor.timestamp, sensor.force_x, sensor.force_y, sensor.force_z)