import serial.tools.list_ports

def list_serial_ports():
    ports = serial.tools.list_ports.comports()
    return [port.device for port in ports]

# Print the list of available serial ports
print("Available Serial Ports:", list_serial_ports())
